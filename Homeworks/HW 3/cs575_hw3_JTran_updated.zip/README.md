# README
## Homework 3
### CS 575 - Numerical Linear Algebra
### Spring 2023
#### John Tran

Based on previous homeworks, a `Jupyter Notebook` as used to code up the homework assignment. To run the code, 
`Python 3.11` was used. For the most part, older versions of `Python` should work except in cases when...

- `match` statements are used to provide switch-like functionality introduced in `Python 3.10` (**not used in this 
  homework**)